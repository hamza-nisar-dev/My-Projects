import paypalrestsdk
from paypalrestsdk import BillingPlan
import logging

paypalrestsdk.configure({
  "mode": "live", # sandbox or live
  "client_id": "AXhC301fBtxP4YFx5K_BXXPg9SG0zo_ZzbqyIYrreQO7Zy578XWoPKAKQ4N6LBebxZwsPCg-zEQ53cXt",
  "client_secret": "EIi74r61Qt6wzuK0pxQNFIl3I-Ws1uWzWTaK_6CpTXpv08M9Abc7MEt9VZd0-tFSTA0Fm0jcAzF-otPn" })

billing_plan = BillingPlan({
    "description": "🔑 6 MONTH ACCESS VIP 🔑  €109.99",
    "merchant_preferences": {
        "auto_bill_amount": "yes",
        "cancel_url": "http://www.cancel.com",
        "initial_fail_amount_action": "continue",
        "max_fail_attempts": "0",
        "return_url": "https://0bb2-2a01-4f8-242-43c3-00-1d28-8501.eu.ngrok.io/subscribe",
    },
    "name": "NationForexSignals",
    "payment_definitions": [
        {
            "amount": {
                "currency": "EUR",
                "value": "109.99"
            },
            "cycles": "0",
            "frequency": "MONTH",
            "frequency_interval": "6",
            "name": "🔑 6 MONTH ACCESS VIP 🔑  €109.99",
            "type": "REGULAR"
        }],
    "type": "INFINITE"
})
if billing_plan.create():
    billing_plan.activate()
    print("Billing Plan [%s] created successfully" % (billing_plan.id))
else:
    print(billing_plan.error)