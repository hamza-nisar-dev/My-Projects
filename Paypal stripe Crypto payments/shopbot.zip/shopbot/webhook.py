import requests
from flask import Flask, request, abort
from coinbase_commerce.webhook import Webhook
import sqlite3
import json
from dateutil import parser
import paypalrestsdk
from paypalrestsdk import BillingAgreement
from datetime import  timedelta
from datetime import date
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram import (ReplyKeyboardMarkup, ReplyKeyboardRemove)
from telegram import Bot
import datetime as dt
app = Flask(__name__)
paypalrestsdk.configure({
  "mode": "live", # sandbox or live
  "client_id": "AXhC301fBtxP4YFx5K_BXXPg9SG0zo_ZzbqyIYrreQO7Zy578XWoPKAKQ4N6LBebxZwsPCg-zEQ53cXt",
  "client_secret": "EIi74r61Qt6wzuK0pxQNFIl3I-Ws1uWzWTaK_6CpTXpv08M9Abc7MEt9VZd0-tFSTA0Fm0jcAzF-otPn" })
bot=Bot("1994434514:AAFJVFzT4K3ifga1gHMA7gZ2ZUvM5eQqwiI")
@app.route('/webhook', methods=['POST'])
def webhook():
    if request.method == 'POST':
        da = request.data.decode('utf-8')
        y = json.loads(da)
        et=y["event_type"]
        print(et)
        if et=="BILLING.SUBSCRIPTION.CANCELLED" or et=="BILLING.SUBSCRIPTION.SUSPENDED":
            id=y["resource"]["id"]
            exp=y["resource"]["agreement_details"]["final_payment_due_date"]
            exp=parser.parse(exp) 
            conn = sqlite3.connect('paypal.db')  
            cursor = conn.execute("SELECT id,pkg FROM COMPANY where ptoken='{}'".format(id))
            for names in cursor:
                ida=names[0]
                pkg=names[1]
            conn = sqlite3.connect("kick.db")  
            conn.execute("UPDATE COMPANY set date='{}', where ID = '{}'".format(exp,ida))
            conn.commit()
            conn.close()
        elif et=="BILLING.SUBSCRIPTION.PAYMENT.FAILED":
            id=y["resource"]["id"]
            exp=y["resource"]["billing_info"]["final_payment_time"]
            exp=parser.parse(exp) 
            conn = sqlite3.connect('paypal.db')  
            cursor = conn.execute("SELECT id,pkg FROM COMPANY where ptoken='{}'".format(id))
            for names in cursor:
                ida=names[0]
                pkg=names[1]
            conn = sqlite3.connect("kick.db")  
            conn.execute("UPDATE COMPANY set date='{}', where ID = '{}'".format(exp,ida))
            conn.commit()
            conn.close()            
    return 'success', 200
@app.route('/subscribe', methods=['GET'])
def subscribe():
    try:
        rn(request.args.get('token'))
        return 'Success', 200 
    except Exception as e:
        rn(request.args.get('token'))
        return 'Success', 200
@app.route('/lifetime', methods=['GET'])
def lifetime():
    try:
        rne(request.args.get('paymentId'))
        return 'Success', 200 
    except Exception as e:
        rne(request.args.get('paymentId'))
        return 'Success', 200

def rne(cn):
        print(cn)
        conn = sqlite3.connect('paypal.db')  
        cursor = conn.execute("SELECT ID FROM COMPANY where ptoken='{}'".format(cn))
        for names in cursor:
            ida=names[0]
        print(ida)
        conn = sqlite3.connect("kick.db")  
        conn.execute("UPDATE COMPANY set date='Lifetime' where ID = '{}' ".format(int(ida)))
        conn.commit()
        conn.close()
        exp=dt.datetime.now().utcnow() + dt.timedelta(days=7)
        c=bot.createChatInviteLink(chat_id= -1001403638093, expire_date=exp,member_limit=1)
        link=c['invite_link']
        keyboard = [[InlineKeyboardButton("Nation Forex Signals VIP", url=link)]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        bot.send_message(chat_id=ida,text="Thank you for your payment\n.Please click the button below to join Channel" 
                ,reply_markup=reply_markup)
        b = "Lifetime"
        bb=date.today()
        cc="🔑 Lifetime VIP ACCESS🔑"
        ff="149,99 € Lifetime"
        text2="Congratulations! You have a new Paypal subscription\n\nUser: {}\nProject: NationForexSignals\nPlan: {}\nBilling: {}\n Received: {}\nStatus: active\nNext payment on: {}\n".format(ida,cc,ff,bb,b)
        bot.send_message(chat_id=1991527010,text=text2)
def rn(cn):
        print(cn)
        billing_agreement_response = BillingAgreement.execute(cn)
        id=billing_agreement_response.id
        print(id)
        conn = sqlite3.connect('paypal.db')  
        cursor = conn.execute("SELECT id,pkg FROM COMPANY where ptoken='{}'".format(cn))
        for names in cursor:
            ida=names[0]
            pkg=names[1]
        print(ida)
        if pkg=="1":
            b = date.today() + timedelta(days=7)
            bb=date.today()
            cc="🔑 1 WEEK VIP ACCESS🔑"
            ff="19,99 € 1 week"
        elif pkg=="2":
            b = date.today() + timedelta(days=30)
            bb=date.today()
            cc="🔑 1 MONTH VIP ACCESS🔑"
            ff="34,99 € 1 month"

        elif pkg=="3":
            b = date.today() + timedelta(days=90)
            bb=date.today()
            cc="🔑 3 MONTH VIP ACCESS🔑"
            ff="74,99 € 3 month"
        elif pkg=="4":
            b = date.today() + timedelta(days=180)
            bb=date.today()
            cc="🔑 6 MONTH VIP ACCESS🔑"
            ff="109,99 € 6 month"

        elif pkg=="5":
            b = "Lifetime"
            bb=date.today()
            cc="🔑 Lifetime VIP ACCESS🔑"
            ff="149,99 € Lifetime"
        text2="Congratulations! You have a new Paypal subscription\n\nUser: {}\nProject: NationForexSignals\nPlan: {}\nBilling: {}\n Received: {}\nStatus: active\nNext payment on: {}\n".format(ida,cc,ff,bb,b)
        conn = sqlite3.connect('agreement.db')
        conn.execute("INSERT INTO COMPANY (ID,agree_id,pkg) \
            VALUES ('{}','{}','{}')".format(ida,id,pkg))
        conn.commit()
        exp=dt.datetime.now().utcnow() + dt.timedelta(days=7)
        c=bot.createChatInviteLink(chat_id= -1001403638093, expire_date=exp,member_limit=1)
        link=c['invite_link']
        keyboard = [[InlineKeyboardButton("Nation Forex Signals VIP", url=link)]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        bot.send_message(chat_id=ida,text="Thank you for your payment\n.Please click the button below to join Channel" 
                ,reply_markup=reply_markup)
        bot.send_message(chat_id=1991527010,text=text2)
@app.route('/crypto', methods=['POST'])
def crypto():
    if request.method == 'POST':
        request_data = request.data.decode('utf-8')
        request_sig = request.headers.get('X-CC-Webhook-Signature', None)
        event = Webhook.construct_event(request_data, request_sig,"7016f921-a9c9-4c9b-b0d2-788f5293acc1")
        et=event.type
        ko=event.data.id
        connection = sqlite3.connect("wallet.db")  
        cursor = connection.execute("SELECT pkg,id FROM COMPANY where code='{}'".format(ko))
        for names in cursor:
            pkg=names[0]
            ida=names[1]
        if et=="charge:confirmed":
                print(ida)
                if pkg=="1":
                  b = date.today() + timedelta(days=7)
                  bb=date.today()
                  cc="🔑 1 WEEK VIP ACCESS🔑"
                  ff="19,99 € 1 week"
                elif pkg=="2":
                  b = date.today() + timedelta(days=30)
                  bb=date.today()
                  cc="🔑 1 MONTH VIP ACCESS🔑"
                  ff="34,99 € 1 month"

                elif pkg=="3":
                  b = date.today() + timedelta(days=90)
                  bb=date.today()
                  cc="🔑 3 MONTH VIP ACCESS🔑"
                  ff="74,99 € 3 month"
                elif pkg=="4":
                  b = date.today() + timedelta(days=180)
                  bb=date.today()
                  cc="🔑 6 MONTH VIP ACCESS🔑"
                  ff="109,99 € 6 month"

                elif pkg=="5":
                  b = "Lifetime"
                  bb=date.today()
                  cc="🔑 Lifetime VIP ACCESS🔑"
                  ff="149,99 € Lifetime"
                text2="Congratulations! You have a new Crypto subscription\n\nUser: {}\nProject: NationForexSignals\nPlan: {}\nBilling: {}\n Received: {}\nStatus: active\nNext payment on: {}\n".format(ida,cc,ff,bb,b)
                conn = sqlite3.connect("kick.db")  
                conn.execute("UPDATE COMPANY set date='{}' where ID = '{}'".format(b,int(ida)))
                conn.commit()
                conn.close()
                exp=dt.datetime.now().utcnow() + dt.timedelta(days=7)
                c=bot.createChatInviteLink(chat_id= -1001403638093, expire_date=exp,member_limit=1)
                link=c['invite_link']
                keyboard = [[InlineKeyboardButton("Nation Forex Signals VIP", url=link)]]
                reply_markup = InlineKeyboardMarkup(keyboard)
                bot.send_message(chat_id=ida,text="Thank you for your payment\n.Please click the button below to join Channel" 
                        ,reply_markup=reply_markup)
                bot.send_message(chat_id=1991527010,text=text2)
        elif et=="charge:pending":
            bot.send_message(chat_id=ida,text="Your transcation is pending will be added on confirmation") 
    return 'success', 200
if __name__ == '__main__':
    app.run()